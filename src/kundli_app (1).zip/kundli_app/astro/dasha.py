"""
Step 4 — Timing engine (Vimshottari Dasha).

This is what produces the "when does this period begin / end" answers that make
chart-grounded astrology feel uncanny. Built from the Moon's nakshatra at birth.
Computes Mahadasha + Antardasha (bhukti) timelines and identifies what is
running *now* so the LLM can reason about current and upcoming periods.
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass

import swisseph as swe

from .ephemeris import NAK_SPAN, _nakshatra_for

# Vimshottari order and durations (years). Total = 120.
DASHA_SEQUENCE = [
    ("Ketu", 7), ("Venus", 20), ("Sun", 6), ("Moon", 10), ("Mars", 7),
    ("Rahu", 18), ("Jupiter", 16), ("Saturn", 19), ("Mercury", 17),
]
TOTAL_YEARS = 120
DAYS_PER_YEAR = 365.2425


@dataclass
class DashaPeriod:
    lord: str
    start: str          # ISO date
    end: str            # ISO date
    sub_periods: list    # list[DashaPeriod] (antardashas) or []


def _add_years(jd: float, years: float) -> float:
    return jd + years * DAYS_PER_YEAR


def _jd_to_iso(jd: float) -> str:
    y, m, d, h = swe.revjul(jd, swe.GREG_CAL)
    return f"{y:04d}-{m:02d}-{d:02d}"


def _seq_from(lord: str):
    """Return the dasha sequence rotated to start at `lord`."""
    idx = next(i for i, (l, _) in enumerate(DASHA_SEQUENCE) if l == lord)
    return DASHA_SEQUENCE[idx:] + DASHA_SEQUENCE[:idx]


def build_dasha_timeline(moon_longitude: float, birth_jd: float):
    """Full Mahadasha timeline (with antardashas) from birth Moon position."""
    _, moon_lord, _, _ = _nakshatra_for(moon_longitude)

    # Balance of the first (birth) mahadasha: fraction of nakshatra still ahead.
    pos_in_nak = moon_longitude % NAK_SPAN
    fraction_elapsed = pos_in_nak / NAK_SPAN

    first_full_years = dict(DASHA_SEQUENCE)[moon_lord]
    first_balance_years = first_full_years * (1 - fraction_elapsed)

    # Back-calc the notional start of the running mahadasha (before birth).
    cursor = _add_years(birth_jd, -(first_full_years - first_balance_years))

    timeline: list[DashaPeriod] = []
    for lord, years in _seq_from(moon_lord):
        start_jd = cursor
        end_jd = _add_years(start_jd, years)
        timeline.append(DashaPeriod(
            lord=lord,
            start=_jd_to_iso(start_jd),
            end=_jd_to_iso(end_jd),
            sub_periods=_build_antardashas(lord, years, start_jd),
        ))
        cursor = end_jd
    return timeline


def _build_antardashas(maha_lord: str, maha_years: float, start_jd: float):
    subs: list[DashaPeriod] = []
    cursor = start_jd
    for sub_lord, sub_years in _seq_from(maha_lord):
        portion = maha_years * (sub_years / TOTAL_YEARS)
        s = cursor
        e = _add_years(s, portion)
        subs.append(DashaPeriod(lord=sub_lord, start=_jd_to_iso(s),
                                end=_jd_to_iso(e), sub_periods=[]))
        cursor = e
    return subs


def current_periods(timeline, on_date: _dt.date | None = None):
    """Identify the Mahadasha + Antardasha running on a given date (default today)."""
    on_date = on_date or _dt.date.today()
    iso = on_date.isoformat()
    running_maha = None
    running_antar = None
    for maha in timeline:
        if maha.start <= iso < maha.end:
            running_maha = maha
            for sub in maha.sub_periods:
                if sub.start <= iso < sub.end:
                    running_antar = sub
                    break
            break
    return running_maha, running_antar

"""
Step 1 — Astronomical compute layer (the real moat).

Wraps Swiss Ephemeris (pyswisseph) to produce a precise, *structured* Vedic
birth chart from raw birth data. We compute everything ourselves from raw
planetary longitudes rather than renting pre-interpreted blurbs from a
third-party astrology API. That is what makes downstream LLM answers sharp.

Sidereal zodiac, Lahiri ayanamsa, Whole-Sign houses (standard Parashari).
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, asdict
from functools import lru_cache
from typing import Optional

import swisseph as swe

# --- Static reference data -------------------------------------------------

SIGNS = [
    "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
    "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces",
]
SIGN_LORDS = [
    "Mars", "Venus", "Mercury", "Moon", "Sun", "Mercury",
    "Venus", "Mars", "Jupiter", "Saturn", "Saturn", "Jupiter",
]

# 27 nakshatras and their Vimshottari dasha lords (drives the timing engine).
NAKSHATRAS = [
    ("Ashwini", "Ketu"), ("Bharani", "Venus"), ("Krittika", "Sun"),
    ("Rohini", "Moon"), ("Mrigashira", "Mars"), ("Ardra", "Rahu"),
    ("Punarvasu", "Jupiter"), ("Pushya", "Saturn"), ("Ashlesha", "Mercury"),
    ("Magha", "Ketu"), ("Purva Phalguni", "Venus"), ("Uttara Phalguni", "Sun"),
    ("Hasta", "Moon"), ("Chitra", "Mars"), ("Swati", "Rahu"),
    ("Vishakha", "Jupiter"), ("Anuradha", "Saturn"), ("Jyeshtha", "Mercury"),
    ("Mula", "Ketu"), ("Purva Ashadha", "Venus"), ("Uttara Ashadha", "Sun"),
    ("Shravana", "Moon"), ("Dhanishta", "Mars"), ("Shatabhisha", "Rahu"),
    ("Purva Bhadrapada", "Jupiter"), ("Uttara Bhadrapada", "Saturn"), ("Revati", "Mercury"),
]

NAK_SPAN = 360.0 / 27.0          # 13°20'
PADA_SPAN = NAK_SPAN / 4.0       # 3°20'

# Planets we compute. Rahu = mean north node; Ketu = exact opposite.
_PLANET_CODES = {
    "Sun": swe.SUN, "Moon": swe.MOON, "Mars": swe.MARS,
    "Mercury": swe.MERCURY, "Jupiter": swe.JUPITER, "Venus": swe.VENUS,
    "Saturn": swe.SATURN, "Rahu": swe.MEAN_NODE,
}

# Natural friendships (very compact dignity model used for prompt context).
EXALTATION = {
    "Sun": "Aries", "Moon": "Taurus", "Mars": "Capricorn", "Mercury": "Virgo",
    "Jupiter": "Cancer", "Venus": "Pisces", "Saturn": "Libra",
}
DEBILITATION = {
    "Sun": "Libra", "Moon": "Scorpio", "Mars": "Cancer", "Mercury": "Pisces",
    "Jupiter": "Capricorn", "Venus": "Virgo", "Saturn": "Aries",
}


@dataclass
class PlanetPosition:
    name: str
    longitude: float          # sidereal ecliptic longitude, 0-360
    sign: str
    sign_index: int           # 0-11
    degree_in_sign: float
    house: int                # 1-12 (whole-sign from ascendant)
    nakshatra: str
    nakshatra_lord: str
    pada: int
    retrograde: bool
    dignity: str              # exalted / debilitated / own / neutral

    def as_dict(self):
        return asdict(self)


@dataclass
class ChartCore:
    julian_day_ut: float
    ascendant_longitude: float
    ascendant_sign: str
    ascendant_sign_index: int
    ascendant_degree: float
    ayanamsa: float
    planets: list  # list[PlanetPosition]
    moon_longitude: float


def _to_julian_day_ut(year, month, day, hour, minute, tz_offset_hours) -> float:
    """Convert local civil time + UTC offset to Julian Day in UT."""
    ut_hour = hour + minute / 60.0 - tz_offset_hours
    return swe.julday(year, month, day, ut_hour, swe.GREG_CAL)


def _nakshatra_for(longitude: float):
    idx = int(longitude // NAK_SPAN) % 27
    name, lord = NAKSHATRAS[idx]
    pada = int((longitude % NAK_SPAN) // PADA_SPAN) + 1
    return name, lord, pada, idx


def _dignity(planet: str, sign: str, sign_index: int) -> str:
    if EXALTATION.get(planet) == sign:
        return "exalted"
    if DEBILITATION.get(planet) == sign:
        return "debilitated"
    if SIGN_LORDS[sign_index] == planet:
        return "own sign"
    return "neutral"


@lru_cache(maxsize=5)  # remember the last 5 natal computations (date-independent)
def compute_chart(
    year: int, month: int, day: int,
    hour: int, minute: int,
    lat: float, lon: float,
    tz_offset_hours: float,
) -> ChartCore:
    """Compute a full sidereal (Lahiri) Vedic chart with whole-sign houses."""
    swe.set_sid_mode(swe.SIDM_LAHIRI, 0, 0)
    jd = _to_julian_day_ut(year, month, day, hour, minute, tz_offset_hours)
    ayan = swe.get_ayanamsa_ut(jd)

    flags = swe.FLG_SWIEPH | swe.FLG_SIDEREAL | swe.FLG_SPEED

    # Ascendant: houses_ex with sidereal flag gives sidereal cusps directly.
    cusps, ascmc = swe.houses_ex(jd, lat, lon, b"W", swe.FLG_SIDEREAL)
    asc_lon = ascmc[0] % 360.0
    asc_sign_index = int(asc_lon // 30)
    asc_sign = SIGNS[asc_sign_index]

    planets: list[PlanetPosition] = []
    moon_lon = 0.0

    def add_planet(name: str, lon_val: float, speed: float):
        nonlocal moon_lon
        lon_val %= 360.0
        sidx = int(lon_val // 30)
        deg_in_sign = lon_val - sidx * 30
        # whole-sign house: sign relative to ascendant sign
        house = ((sidx - asc_sign_index) % 12) + 1
        nak, naklord, pada, _ = _nakshatra_for(lon_val)
        planets.append(PlanetPosition(
            name=name, longitude=round(lon_val, 4), sign=SIGNS[sidx],
            sign_index=sidx, degree_in_sign=round(deg_in_sign, 4),
            house=house, nakshatra=nak, nakshatra_lord=naklord, pada=pada,
            retrograde=(speed < 0),
            dignity=_dignity(name, SIGNS[sidx], sidx),
        ))
        if name == "Moon":
            moon_lon = lon_val

    for name, code in _PLANET_CODES.items():
        res, _flag = swe.calc_ut(jd, code, flags)
        add_planet(name, res[0], res[3])

    # Ketu = Rahu + 180
    rahu = next(p for p in planets if p.name == "Rahu")
    add_planet("Ketu", (rahu.longitude + 180.0) % 360.0, -1.0)  # nodes always retro

    return ChartCore(
        julian_day_ut=jd,
        ascendant_longitude=round(asc_lon, 4),
        ascendant_sign=asc_sign,
        ascendant_sign_index=asc_sign_index,
        ascendant_degree=round(asc_lon - asc_sign_index * 30, 4),
        ayanamsa=round(ayan, 4),
        planets=planets,
        moon_longitude=moon_lon,
    )

"""
Derive the correct UTC offset for a birth event from coordinates + birth datetime.

Uses the IANA tz database (via zoneinfo) so the offset reflects the rules that
were actually in force on the birth date — historical base-offset changes AND
DST. This is more correct for old charts than a 'current offset' lookup, and it
removes the need for Google's Time Zone API. Coordinates come from Google Places
autocomplete on the frontend.
"""
from __future__ import annotations

import datetime as _dt
from zoneinfo import ZoneInfo

from timezonefinder import TimezoneFinder

_tf = TimezoneFinder()


def offset_for(lat: float, lon: float, year: int, month: int, day: int,
               hour: int, minute: int) -> dict:
    tzname = _tf.timezone_at(lat=lat, lng=lon)
    if not tzname:
        # ocean / unknown: fall back to nautical offset from longitude
        return {"tz_name": None, "offset_hours": round(lon / 15.0, 2),
                "approximate": True}
    local = _dt.datetime(year, month, day, hour, minute, tzinfo=ZoneInfo(tzname))
    offset = local.utcoffset().total_seconds() / 3600.0
    return {"tz_name": tzname, "offset_hours": round(offset, 2), "approximate": False}

"""
Step 2 — Assemble the chart and serialize a dense, structured context block.

The single biggest quality lever over an AstrologyAPI-style app: we hand the
model exact, machine-derived facts (degrees, house lords, dasha dates, transits)
to *reason over* — not generic horoscope prose to paraphrase.
"""
from __future__ import annotations

import datetime as _dt

from .ephemeris import compute_chart, SIGNS, SIGN_LORDS
from .dasha import build_dasha_timeline, current_periods
from .transits import current_transits


def build_full_chart(birth: dict) -> dict:
    """birth = {year,month,day,hour,minute,lat,lon,tz_offset_hours,name,place}"""
    core = compute_chart(
        birth["year"], birth["month"], birth["day"],
        birth["hour"], birth["minute"],
        birth["lat"], birth["lon"], birth["tz_offset_hours"],
    )
    timeline = build_dasha_timeline(core.moon_longitude, core.julian_day_ut)
    maha, antar = current_periods(timeline)
    transits = current_transits(core.ascendant_sign_index)

    # House lords (which planet rules each of the 12 houses from this lagna).
    house_lords = {}
    for h in range(12):
        sign_idx = (core.ascendant_sign_index + h) % 12
        house_lords[h + 1] = {"sign": SIGNS[sign_idx], "lord": SIGN_LORDS[sign_idx]}

    return {
        "person": {"name": birth.get("name", ""), "place": birth.get("place", "")},
        "ascendant": {
            "sign": core.ascendant_sign,
            "degree": core.ascendant_degree,
            "lord": SIGN_LORDS[core.ascendant_sign_index],
        },
        "ayanamsa": core.ayanamsa,
        "planets": [p.as_dict() for p in core.planets],
        "house_lords": house_lords,
        "dasha": {
            "current_mahadasha": {"lord": maha.lord, "start": maha.start, "end": maha.end} if maha else None,
            "current_antardasha": {"lord": antar.lord, "start": antar.start, "end": antar.end} if antar else None,
            "timeline": [{"lord": m.lord, "start": m.start, "end": m.end} for m in timeline],
        },
        "transits": transits,
    }


def serialize_context(chart: dict) -> str:
    """Render the chart as a compact, LLM-friendly context block."""
    L = []
    p = chart["person"]
    if p["name"] or p["place"]:
        L.append(f"NATIVE: {p['name'] or 'Unknown'} — born at {p['place'] or 'unknown place'}")
    asc = chart["ascendant"]
    L.append(f"LAGNA (Ascendant): {asc['sign']} {asc['degree']:.2f}° | Lagna lord: {asc['lord']}")
    L.append(f"Ayanamsa (Lahiri): {chart['ayanamsa']:.3f}°  | Zodiac: Sidereal | Houses: Whole-Sign")

    L.append("\nPLANETARY POSITIONS:")
    for pl in chart["planets"]:
        retro = " (R)" if pl["retrograde"] else ""
        L.append(
            f"  {pl['name']:8} {pl['sign']:12} {pl['degree_in_sign']:5.2f}°  "
            f"House {pl['house']:>2}  {pl['nakshatra']} pada {pl['pada']}  "
            f"[{pl['dignity']}]{retro}"
        )

    L.append("\nHOUSE LORDS (from Lagna):")
    for h, info in chart["house_lords"].items():
        L.append(f"  House {h:>2} ({info['sign']}): ruled by {info['lord']}")

    d = chart["dasha"]
    L.append("\nVIMSHOTTARI DASHA:")
    if d["current_mahadasha"]:
        m = d["current_mahadasha"]
        L.append(f"  RUNNING Mahadasha: {m['lord']}  ({m['start']} -> {m['end']})")
    if d["current_antardasha"]:
        a = d["current_antardasha"]
        L.append(f"  RUNNING Antardasha: {a['lord']}  ({a['start']} -> {a['end']})")
    L.append("  Upcoming mahadasha sequence:")
    today = _dt.date.today().isoformat()
    for m in d["timeline"]:
        if m["end"] >= today:
            L.append(f"    {m['lord']:8} {m['start']} -> {m['end']}")

    t = chart["transits"]
    L.append(f"\nCURRENT TRANSITS (gochar, {t['date']}), house counted from natal Lagna:")
    for pl in t["planets"]:
        retro = " (R)" if pl["retrograde"] else ""
        L.append(f"  {pl['name']:8} {pl['sign']:12} {pl['degree_in_sign']:5.2f}°  "
                 f"House {pl['house_from_lagna']:>2}{retro}")

    return "\n".join(L)

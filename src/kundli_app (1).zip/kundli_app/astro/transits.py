"""Current planetary transits (gochar) — feeds 'what's happening now' reasoning."""
from __future__ import annotations

import datetime as _dt
import swisseph as swe

from .ephemeris import SIGNS, _PLANET_CODES, _nakshatra_for


def current_transits(natal_asc_sign_index: int, on_date: _dt.date | None = None):
    """Sidereal positions of planets right now, with house relative to natal lagna."""
    on_date = on_date or _dt.date.today()
    swe.set_sid_mode(swe.SIDM_LAHIRI, 0, 0)
    jd = swe.julday(on_date.year, on_date.month, on_date.day, 12.0, swe.GREG_CAL)
    flags = swe.FLG_SWIEPH | swe.FLG_SIDEREAL | swe.FLG_SPEED

    out = []
    for name, code in _PLANET_CODES.items():
        res, _ = swe.calc_ut(jd, code, flags)
        lon = res[0] % 360.0
        sidx = int(lon // 30)
        nak, _, pada, _ = _nakshatra_for(lon)
        house = ((sidx - natal_asc_sign_index) % 12) + 1
        out.append({
            "name": name, "sign": SIGNS[sidx],
            "degree_in_sign": round(lon - sidx * 30, 2),
            "house_from_lagna": house, "nakshatra": nak, "pada": pada,
            "retrograde": res[3] < 0,
        })
    # Ketu
    rahu = next(p for p in out if p["name"] == "Rahu")
    rsign = SIGNS.index(rahu["sign"])
    ketu_sidx = (rsign + 6) % 12
    out.append({
        "name": "Ketu", "sign": SIGNS[ketu_sidx],
        "degree_in_sign": rahu["degree_in_sign"],
        "house_from_lagna": ((ketu_sidx - natal_asc_sign_index) % 12) + 1,
        "nakshatra": "-", "pada": 0, "retrograde": True,
    })
    return {"date": on_date.isoformat(), "planets": out}
